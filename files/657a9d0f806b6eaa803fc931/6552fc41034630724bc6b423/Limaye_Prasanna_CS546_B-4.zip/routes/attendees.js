// Import the express router as shown in the lecture code
// Note: please do not forget to export the router!
import { Router } from "express";
import validateFunctions from "../helpers.js";
import { attendeeData } from "../data/index.js";
const router = Router();

router
  .route("/:eventId")
  .get(async (req, res) => {
    //code here for GET
    try {
      req.params.eventId = validateFunctions.validateObjectId(
        req.params.eventId
      );

      const event = await attendeeData.getAllAttendees(req.params.eventId);

      return res.status(200).json(event);
    } catch (e) {
      console.log(e);
      if (e === "No Event") {
        return res
          .status(404)
          .json({ error: `No Event found with id ${req.params.eventId}` });
      }
      return res.status(400).send(e);
    }
  })
  .post(async (req, res) => {
    //code here for POST

    try {
      req.params.eventId = validateFunctions.validateObjectId(
        req.params.eventId
      );

      const inputAttendeeData = req.body;
      if (!inputAttendeeData || Object.keys(inputAttendeeData).length === 0) {
        return res
          .status(400)
          .json({ error: "There are no fields in the request body" });
      }
      if (
        !inputAttendeeData.hasOwnProperty("firstName") ||
        !inputAttendeeData.hasOwnProperty("lastName") ||
        !inputAttendeeData.hasOwnProperty("emailAddress")
      ) {
        return res.status(400).json({
          error:
            "Request body creating attendee should have firstName, lastName, emailAddress",
        });
      }
      const newAttendee = await attendeeData.createAttendee(
        req.params.eventId,
        inputAttendeeData.firstName,
        inputAttendeeData.lastName,
        inputAttendeeData.emailAddress
      );

      return res.status(200).json(newAttendee);
    } catch (e) {
      if (e === "No Event") {
        return res.status(404).json({
          error: `No Event found with id ${req.params.eventId}`,
        });
      }
      console.log(e);
      return res.status(400).send(e);
    }
  });

router
  .route("/attendee/:attendeeId")
  .get(async (req, res) => {
    //code here for GET
    try {
      req.params.attendeeId = validateFunctions.validateObjectId(
        req.params.attendeeId
      );

      const attendee = await attendeeData.getAttendee(req.params.attendeeId);
      return res.status(200).json(attendee);
    } catch (e) {
      console.log(e);
      if (e === "No Attendee") {
        return res.status(404).json({
          error: `No Attendee found with id ${req.params.attendeeId}`,
        });
      }
      return res.status(400).send(e);
    }
  })
  .delete(async (req, res) => {
    //code here for DELETE
    try {
      req.params.attendeeId = validateFunctions.validateObjectId(
        req.params.attendeeId
      );
      const output = await attendeeData.removeAttendee(req.params.attendeeId);
      return res.status(200).json(output);
    } catch (e) {
      console.log(e);

      if (e === "No Attendee") {
        return res.status(404).json({
          error: `No Attendee found with id ${req.params.attendeeId}`,
        });
      }

      return res.status(400).send(e);
    }
  });

export default router;
