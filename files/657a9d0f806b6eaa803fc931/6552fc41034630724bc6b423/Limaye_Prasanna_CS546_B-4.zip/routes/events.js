// Import the express router as shown in the lecture code
// Note: please do not forget to export the router!
import { Router } from "express";
import validateFunctions from "../helpers.js";
import { eventData } from "../data/index.js";
const router = Router();
router
  .route("/")
  .get(async (req, res) => {
    //code here for GET
    try {
      const allEvents = await eventData.getAll();
      res.json(allEvents);
    } catch (e) {
      console.log(e);
      return res.status(500).send(e);
    }
  })
  .post(async (req, res) => {
    //code here for POST
    const inputEventData = req.body;
    // console.log(eventData);

    if (!inputEventData || Object.keys(inputEventData).length === 0) {
      return res
        .status(400)
        .json({ error: "There are no fields in the request body" });
    }

    if (!inputEventData.eventName) {
      return res.status(400).json({ error: "You must provide an eventName" });
    }
    if (!inputEventData.description) {
      return res.status(400).json({ error: "You must provide a description" });
    }
    if (!inputEventData.eventLocation) {
      return res
        .status(400)
        .json({ error: "You must provide an eventLocation" });
    }
    if (!inputEventData.contactEmail) {
      return res.status(400).json({ error: "You must provide a contactEmail" });
    }
    if (!inputEventData.hasOwnProperty("maxCapacity")) {
      return res.status(400).json({ error: "You must provide a maxCapacity" });
    }
    if (!inputEventData.hasOwnProperty("priceOfAdmission")) {
      return res
        .status(400)
        .json({ error: "You must provide a priceOfAdmission" });
    }
    if (!inputEventData.eventDate) {
      return res.status(400).json({ error: "You must provide an eventDate" });
    }
    if (!inputEventData.startTime) {
      return res.status(400).json({ error: "You must provide a startTime" });
    }
    if (!inputEventData.endTime) {
      return res.status(400).json({ error: "You must provide an endTime" });
    }
    if (!inputEventData.hasOwnProperty("publicEvent")) {
      return res.status(400).json({ error: "You must provide a publicEvent" });
    }
    try {
      const eventCreated = await eventData.create(
        inputEventData.eventName,
        inputEventData.description,
        inputEventData.eventLocation,
        inputEventData.contactEmail,
        inputEventData.maxCapacity,
        inputEventData.priceOfAdmission,
        inputEventData.eventDate,
        inputEventData.startTime,
        inputEventData.endTime,
        inputEventData.publicEvent
      );
      res.json(eventCreated);
    } catch (e) {
      console.log(e);
      return res.status(404).send(e);
    }
  });

router
  .route("/:eventId")
  .get(async (req, res) => {
    //code here for GET
    try {
      req.params.eventId = validateFunctions.validateObjectId(
        req.params.eventId
      );

      const event = await eventData.get(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (e) {
      console.log(e);

      if (e === "No Event") {
        return res.status(404).json({
          error: `No Event found with id ${req.params.eventId}`,
        });
      }

      return res.status(400).send(e);
    }
  })
  .delete(async (req, res) => {
    //code here for DELETE
    req.params.eventId = validateFunctions.validateObjectId(req.params.eventId);
    try {
      const event = await eventData.get(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
    } catch (e) {
      console.log(e);
      if (e === "No Event") {
        return res.status(404).json({
          error: `No Event found with id ${req.params.eventId}`,
        });
      }
      return res.status(404).send(e);
    }

    try {
      const event = await eventData.remove(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
      res.json(event);
    } catch (e) {
      console.log(e);
      return res.status(400).send(e);
    }
  })
  .put(async (req, res) => {
    //code here for PUT

    const inputEventData = req.body;
    // console.log(eventData);
    if (!inputEventData || Object.keys(inputEventData).length === 0) {
      return res
        .status(400)
        .json({ error: "There are no fields in the request body" });
    }

    if (!inputEventData.eventName) {
      return res.status(400).json({ error: "You must provide an eventName" });
    }
    if (!inputEventData.description) {
      return res.status(400).json({ error: "You must provide a description" });
    }
    if (!inputEventData.eventLocation) {
      return res
        .status(400)
        .json({ error: "You must provide an eventLocation" });
    }
    if (!inputEventData.contactEmail) {
      return res.status(400).json({ error: "You must provide a contactEmail" });
    }
    if (!inputEventData.hasOwnProperty("maxCapacity")) {
      return res.status(400).json({ error: "You must provide a maxCapacity" });
    }
    if (!inputEventData.hasOwnProperty("priceOfAdmission")) {
      return res
        .status(400)
        .json({ error: "You must provide a priceOfAdmission" });
    }
    if (!inputEventData.eventDate) {
      return res.status(400).json({ error: "You must provide an eventDate" });
    }
    if (!inputEventData.startTime) {
      return res.status(400).json({ error: "You must provide a startTime" });
    }
    if (!inputEventData.endTime) {
      return res.status(400).json({ error: "You must provide an endTime" });
    }
    if (!inputEventData.hasOwnProperty("publicEvent")) {
      return res.status(400).json({ error: "You must provide a publicEvent" });
    }

    try {
      const event = await eventData.get(req.params.eventId);
      if (!event) {
        return res.status(404).json({ error: "Event not found" });
      }
    } catch (e) {
      console.log(e);
      if (e === "No Event") {
        return res.status(404).json({
          error: `No Event found with id ${req.params.eventId}`,
        });
      }
      return res.status(404).send(e);
    }

    try {
      const event = await eventData.update(
        req.params.eventId,
        inputEventData.eventName,
        inputEventData.description,
        inputEventData.eventLocation,
        inputEventData.contactEmail,
        inputEventData.maxCapacity,
        inputEventData.priceOfAdmission,
        inputEventData.eventDate,
        inputEventData.startTime,
        inputEventData.endTime,
        inputEventData.publicEvent
      );
      res.json(event);
    } catch (e) {
      console.log(e);
      return res.status(400).send(e);
    }
  });
export default router;
