// This file should import both data files and export them as shown in the lecture code
import * as eventDataFunctions from "./events.js";
import * as AttendeeDataFunctions from "./attendees.js";

export const eventData = eventDataFunctions;
export const attendeeData = AttendeeDataFunctions;

export default { eventData, attendeeData };
