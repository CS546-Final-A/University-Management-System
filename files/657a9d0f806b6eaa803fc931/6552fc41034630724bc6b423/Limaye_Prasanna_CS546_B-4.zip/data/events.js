// This data file should export all functions using the ES6 standard as shown in the lecture code
import validateFunctions from "../helpers.js";
import { events } from "../config/mongoCollections.js";
import { ObjectId } from "mongodb";
const validateEvent = (
  eventName,
  description,
  eventLocation,
  contactEmail,
  maxCapacity,
  priceOfAdmission,
  eventDate,
  startTime,
  endTime,
  publicEvent
) => {
  startTime = validateFunctions.validateTimeFormat(startTime);
  endTime = validateFunctions.validateTimeFormat(endTime);

  validateFunctions.validateStringLength(eventName, 5);
  validateFunctions.validateStringLength(description, 25);
  validateFunctions.validateDateWithCurrentDate(new Date(eventDate));
  validateFunctions.validateObject(eventLocation);
  validateFunctions.validateStringLength(eventLocation.streetAddress, 3);
  validateFunctions.validateStringLength(eventLocation.city, 3);
  validateFunctions.validateTime(startTime, endTime);
  const validStateAbbreviations = [
    "AL",
    "AK",
    "AZ",
    "AR",
    "CA",
    "CO",
    "CT",
    "DE",
    "DC",
    "FL",
    "GA",
    "HI",
    "ID",
    "IL",
    "IN",
    "IA",
    "KS",
    "KY",
    "LA",
    "ME",
    "MD",
    "MA",
    "MI",
    "MN",
    "MO",
    "MS",
    "MT",
    "NE",
    "NV",
    "NH",
    "NJ",
    "NM",
    "NY",
    "NC",
    "ND",
    "OH",
    "OK",
    "OR",
    "PA",
    "RI",
    "SC",
    "SD",
    "TN",
    "TX",
    "UT",
    "VT",
    "VA",
    "WA",
    "WV",
    "WI",
    "WY",
  ];
  if (!validStateAbbreviations.includes(eventLocation.state)) {
    throw `${eventLocation.state} should be a valid two character state abbreviation`;
  }

  if (!/^\d{5}$/.test(eventLocation.zip)) {
    throw "Zip code should be a string that contains 5 numbers";
  }
  if (maxCapacity <= 0 || !Number.isInteger(maxCapacity)) {
    throw "Max capacity should be a positive whole number > 0";
  }
  if (
    priceOfAdmission < 0 ||
    (priceOfAdmission > 0 &&
      !/^\d+(\.\d{1,2})?$/.test(priceOfAdmission.toString()))
  ) {
    throw "Price of admission should be a positive whole number, or contain at most 2 decimal numbers";
  }
};

export const create = async (
  eventName,
  description,
  eventLocation,
  contactEmail,
  maxCapacity,
  priceOfAdmission,
  eventDate,
  startTime,
  endTime,
  publicEvent
) => {
  //Implement Code here

  eventName = validateFunctions.validateString(eventName);
  description = validateFunctions.validateString(description);
  eventLocation = {
    streetAddress: validateFunctions.validateString(
      eventLocation.streetAddress
    ),
    city: validateFunctions.validateString(eventLocation.city),
    state: validateFunctions.validateString(eventLocation.state.toUpperCase()),
    zip: validateFunctions.validateString(eventLocation.zip),
  };

  contactEmail = validateFunctions.validateEmail(contactEmail);
  maxCapacity = validateFunctions.validateNumber(maxCapacity);
  priceOfAdmission = validateFunctions.validateNumber(priceOfAdmission);
  eventDate = validateFunctions.validateDate(eventDate);
  startTime = validateFunctions.validateString(startTime);
  endTime = validateFunctions.validateString(endTime);
  publicEvent = validateFunctions.validateBoolean(publicEvent);

  validateEvent(
    eventName,
    description,
    eventLocation,
    contactEmail,
    maxCapacity,
    priceOfAdmission,
    eventDate,
    startTime,
    endTime,
    publicEvent
  );
  let attendees = [];
  let totalNumberOfAttendees = 0;
  const inputEvent = {
    eventName,
    description,
    eventLocation,
    contactEmail,
    maxCapacity,
    priceOfAdmission,
    eventDate,
    startTime,
    endTime,
    publicEvent,
    attendees,
    totalNumberOfAttendees,
  };
  const eventCollection = await events();
  const insertEvent = await eventCollection.insertOne(inputEvent);
  if (!insertEvent.acknowledged || !insertEvent.insertedId) {
    throw "Could not add event";
  }

  let newEvent = await get(insertEvent.insertedId.toString());
  // console.log(newEvent);
  return newEvent;
};

export const getAll = async () => {
  const eventCollection = await events();
  const allEvents = await eventCollection
    .find({}, { projection: { eventName: 1 } })
    .toArray();
  // console.log(allEvents);
  return allEvents;
};

export const get = async (eventId) => {
  //Implement Code here
  eventId = validateFunctions.validateObjectId(eventId);
  const eventCollection = await events();
  const event = await eventCollection.findOne({ _id: new ObjectId(eventId) });
  if (!event) {
    throw "No Event";
  }
  return event;
};

export const remove = async (eventId) => {
  //Implement Code here
  eventId = validateFunctions.validateObjectId(eventId);
  const eventCollection = await events();
  const deletionInfo = await eventCollection.findOneAndDelete({
    _id: new ObjectId(eventId),
  });

  if (!deletionInfo) {
    throw `Could not delete event with id of ${id}`;
  }
  return { eventName: deletionInfo.eventName, deleted: true };
};

export const update = async (
  eventId,
  eventName,
  description,
  eventLocation,
  contactEmail,
  maxCapacity,
  priceOfAdmission,
  eventDate,
  startTime,
  endTime,
  publicEvent
) => {
  //Implement Code here
  eventId = validateFunctions.validateObjectId(eventId);
  eventName = validateFunctions.validateString(eventName);
  description = validateFunctions.validateString(description);
  eventLocation = {
    streetAddress: validateFunctions.validateString(
      eventLocation.streetAddress
    ),
    city: validateFunctions.validateString(eventLocation.city),
    state: validateFunctions.validateString(eventLocation.state.toUpperCase()),
    zip: validateFunctions.validateString(eventLocation.zip),
  };

  contactEmail = validateFunctions.validateEmail(contactEmail);
  maxCapacity = validateFunctions.validateNumber(maxCapacity);
  priceOfAdmission = validateFunctions.validateNumber(priceOfAdmission);
  eventDate = validateFunctions.validateDate(eventDate);
  startTime = validateFunctions.validateString(startTime);
  endTime = validateFunctions.validateString(endTime);
  publicEvent = validateFunctions.validateBoolean(publicEvent);

  validateEvent(
    eventName,
    description,
    eventLocation,
    contactEmail,
    maxCapacity,
    priceOfAdmission,
    eventDate,
    startTime,
    endTime,
    publicEvent
  );

  const eventCollection = await events();
  const updateEvent = await eventCollection.findOneAndUpdate(
    { _id: new ObjectId(eventId) },
    {
      $set: {
        eventName,
        description,
        eventLocation,
        contactEmail,
        maxCapacity,
        priceOfAdmission,
        eventDate,
        startTime,
        endTime,
        publicEvent,
      },
    },
    { returnDocument: "after" }
  );
  if (!updateEvent) {
    throw "Could not update post";
  }
  return updateEvent;
};
