// This data file should export all functions using the ES6 standard as shown in the lecture code
import validateFunctions from "../helpers.js";
import { events } from "../config/mongoCollections.js";
import { eventData } from "../data/index.js";
import { ObjectId } from "mongodb";

export const createAttendee = async (
  eventId,
  firstName,
  lastName,
  emailAddress
) => {
  //Implement Code here
  try {
    eventId = validateFunctions.validateObjectId(eventId);
    firstName = validateFunctions.validateString(firstName);
    lastName = validateFunctions.validateString(lastName);
    emailAddress = validateFunctions.validateEmail(emailAddress);

    const event = await eventData.get(eventId);

    if (event.length === 0) {
      throw "No Event";
    }
    const currentAttendees = event.attendees;
    const maxCapacity = event.maxCapacity;
    const totalNumberOfAttendees = event.totalNumberOfAttendees;
    console.log(totalNumberOfAttendees);
    const isEmailInAttendees = currentAttendees.some(
      (attendee) =>
        attendee.emailAddress.toLowerCase() === emailAddress.toLowerCase()
    );

    if (currentAttendees.length === maxCapacity) {
      throw `Event is at max capacity, cannot add the attendee ${firstName} ${lastName}`;
    }

    if (isEmailInAttendees) {
      throw `Email Id ${emailAddress} already present in the attendee list`;
    }

    const newAttendee = {
      _id: new ObjectId(),
      firstName: firstName,
      lastName: lastName,
      emailAddress: emailAddress,
    };
    const eventCollection = await events();

    await eventCollection.updateOne(
      { _id: new ObjectId(eventId) },
      { $set: { totalNumberOfAttendees: currentAttendees.length + 1 } }
    );
    await eventCollection.updateOne(
      { _id: new ObjectId(eventId) },
      { $addToSet: { attendees: newAttendee } }
    );

    return await eventData.get(eventId);
  } catch (e) {
    throw e;
  }
};

export const getAllAttendees = async (eventId) => {
  //Implement Code here
  try {
    eventId = validateFunctions.validateObjectId(eventId);
    const event = await eventData.get(eventId);
    if (event.length === 0) {
      throw "No Attendee";
    }
    return event.attendees;
  } catch (e) {
    throw e;
  }
};

export const getAttendee = async (attendeeId) => {
  //Implement Code here
  try {
    attendeeId = validateFunctions.validateObjectId(attendeeId);
    const eventCollection = await events();
    const event = await eventCollection.findOne({
      "attendees._id": new ObjectId(attendeeId),
    });
    if (!event) {
      throw "No Attendee";
    }

    return event.attendees.filter(
      (attendee) => attendee._id.toString() === attendeeId
    )[0];
  } catch (e) {
    throw e;
  }
};

export const removeAttendee = async (attendeeId) => {
  //Implement Code here

  try {
    attendeeId = validateFunctions.validateObjectId(attendeeId);

    const eventCollection = await events();
    const event = await eventCollection.findOne({
      "attendees._id": new ObjectId(attendeeId),
    });
    if (!event) {
      throw `No Attendee`;
    }
    const currentAttendees = event.attendees;
    const totalNumberOfAttendees = event.totalNumberOfAttendees;
    const newAttendees = currentAttendees.filter(
      (attendee) => attendee._id.toString() !== attendeeId
    );
    await eventCollection.updateOne(
      { _id: new ObjectId(event._id) },
      { $set: { attendees: newAttendees } },
      { $set: { totalNumberOfAttendees: totalNumberOfAttendees - 1 } }
    );

    await eventCollection.updateOne(
      { _id: new ObjectId(event._id) },
      { $set: { totalNumberOfAttendees: totalNumberOfAttendees - 1 } }
    );
    return await eventData.get(event._id.toString());
  } catch (e) {
    throw e;
  }
};
