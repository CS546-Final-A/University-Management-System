// You can add and export any helper functions you want here - if you aren't using any, then you can just leave this file as is
//You can add and export any helper functions you want here. If you aren't using any, then you can just leave this file as is.
import * as EmailValidator from "email-validator";

import { ObjectId } from "mongodb";

const validateFunctions = {
  validateNumber(input) {
    if (typeof input !== "number") {
      throw `${input} should be a number`;
    }
    return input;
  },
  validateString(input) {
    if (typeof input !== "string") {
      throw "Input is not a valid string";
    }
    input = input.trim();
    if (input.length === 0) {
      throw "Input is not a valid string";
    }

    return input;
  },

  validateStringLength(input, minLength) {
    input = this.validateString(input);
    if (input.trim().length < minLength) {
      throw `${input} string is not of required length ${minLength}`;
    }

    return input;
  },

  validateEmail(input) {
    //console.log("before", input);
    input = this.validateString(input);
    //console.log(input);
    if (!EmailValidator.validate(input)) {
      throw `${input} is not a valid email`;
    }
    return input;
  },

  validateDate(input) {
    input = this.validateString(input);

    const dateRegex = /^(0[1-9]|1[0-2])\/(0[1-9]|[12][0-9]|3[01])\/\d{4}$/;

    if (!dateRegex.test(input)) {
      throw 'Invalid date format. Please use "MM/DD/YYYY" format.';
    }

    const parts = input.split("/");
    const month = parseInt(parts[0], 10);
    const day = parseInt(parts[1], 10);
    const year = parseInt(parts[2], 10);

    if (month < 1 || month > 12 || isNaN(year)) {
      throw "Invalid date.";
    }

    const validDays = {
      1: 31, // January
      2: 28, // February (assuming non-leap year)
      3: 31, // March
      4: 30, // April
      5: 31, // May
      6: 30, // June
      7: 31, // July
      8: 31, // August
      9: 30, // September
      10: 31, // October
      11: 30, // November
      12: 31, // December
    };
    if (year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0)) {
      // Leap year, February has 29 days
      validDays[2] = 29;
    }

    if (day < 1 || day > validDays[month]) {
      throw "Invalid date. Day is out of range for the selected month.";
    }
    return input;
  },

  validateDateWithCurrentDate(input) {
    if (!(input instanceof Date)) {
      throw `${input} is not a valid date`;
    }
    const currentDate = new Date();
    if (input < currentDate) {
      throw `${input} date is less than current date ${currentDate}`;
    }
  },
  validateTimeFormat(time) {
    time = time.trim();
    //console.log("time received is ", time);
    if (!/^([1-9]|1[0-2]):[0-5][0-9].(AM|PM)$/.test(time)) {
      throw `${time} is not a valid time in 12-hour AM/PM format`;
    }
    return time;
  },

  validateBoolean(input) {
    if (typeof input !== "boolean") {
      throw `${input} is not a valid boolean`;
    }
    return input;
  },

  validateObject(input) {
    if (typeof input !== "object") {
      throw `${input} is not a valid object`;
    }
  },
  validateObjectId(input) {
    input = input.trim();
    if (ObjectId.isValid(input) === false) {
      throw `${input} is not a valid ObjectId`;
    }
    return input;
  },

  validateTime(startTime, endTime) {
    this.validateTimeFormat(startTime);
    this.validateTimeFormat(endTime);
    let startTimeArr = startTime.split(":");
    let endTimeArr = endTime.split(":");

    let startHour = parseInt(startTimeArr[0]);
    let startMinute = parseInt(startTimeArr[1].substring(0, 2));
    let startPeriod = startTimeArr[1].substring(2, 4);

    let endHour = parseInt(endTimeArr[0]);
    let endMinute = parseInt(endTimeArr[1].substring(0, 2));
    let endPeriod = endTimeArr[1].substring(2, 4);

    if (startPeriod === "PM" && startHour !== 12) {
      startHour += 12;
    }
    if (endPeriod === "PM" && endHour !== 12) {
      endHour += 12;
    }
    if (startPeriod === "AM" && startHour === 12) {
      startHour = 0;
    }
    if (endPeriod === "AM" && endHour === 12) {
      endHour = 0;
    }

    const start = new Date(0, 0, 0, startHour, startMinute);
    const end = new Date(0, 0, 0, endHour, endMinute);

    if (start >= end) {
      throw "End time should be later than start time";
    }

    const diffInMinutes = (end - start) / 1000 / 60;
    if (diffInMinutes < 30) {
      throw "End time should be at least 30 minutes later than start time";
    }
  },
};

export default validateFunctions;
