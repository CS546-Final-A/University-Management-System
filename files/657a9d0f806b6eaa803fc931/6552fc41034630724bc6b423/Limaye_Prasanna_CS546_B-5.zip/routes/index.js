import chatacterRoutes from "./characters.js";
import path from "path";

const constructorMethod = (app) => {
  app.use("/", chatacterRoutes);

  app.use((req, res) => {
    res.status(404).render("error", { error: "Page not found" });
  });
};

export default constructorMethod;
