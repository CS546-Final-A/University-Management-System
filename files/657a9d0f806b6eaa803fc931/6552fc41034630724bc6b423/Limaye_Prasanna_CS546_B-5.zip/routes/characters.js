//import express and express router as shown in lecture code and worked in previous labs.  Import your data functions from /data/characters.js that you will call in your routes below
import { Router } from "express";
const router = Router();
import * as characterDataFunctions from "../data/characters.js";
import validation from "../helpers.js";

router.route("/").get(async (req, res) => {
  //code here for GET will render the home handlebars file  
  res.render("home",{title : "Marvel Character Finder"});

});

router.route("/searchmarvelcharacters").post(async (req, res) => {
  //code here for POST this is where your form will be submitting searchCharacterByName and then call your data function passing in the searchCharacterByName and then rendering the search results of up to 15 characters.
  let output;
  let searchTerm;
  try{
    console.log(req.body)
    searchTerm = validation.checkString(req.body.searchCharacterByName, "searchCharacterByName");

    output = await characterDataFunctions.searchCharacterByName(searchTerm);
}catch(e){
  res.status(400).render('error', { title: 'Error', paragraph : "Invalid search term provided" });
  return;
}
if (output.length === 0) {
  res.render('characterSearchResults', { title: 'Marvel Character Not Found', searchTerm: searchTerm, notFound: true });
  return;
}

res.render('characterSearchResults', { title: 'Marvel Characters Found', searchTerm: searchTerm, characters:output });

});

router.route("/marvelcharacter/:id").get(async (req, res) => {
  //code here for GET a single character
  try{
  
  let character = await characterDataFunctions.searchCharacterById(req.params.id);
  if(character === "Character not found"){
    res.status(404).render('error', { title: 'Character Not Found', paragraph : `Character for id ${req.params.id} not found \n Please click on the link below to search for more characters` });
    return;
  }
  
  console.log(character)
  const characterName = character.name?character.name:"Marvel Character";
  const characterDescription = character.description;
  const characterImage = character.thumbnail.path+"/portrait_uncanny." + character.thumbnail.extension;
  const characterComics = character.comics.items;
  console.log(characterImage)
  res.render('characterById', { title:characterName, characterName, characterDescription, characterImage, characterComics });
}catch(e){
  res.status(404).render('error', { title: 'Character Not Found', paragraph : `Character for id ${req.params.id} not found \n Please click on the link below to search for more characters` });
  return;
}

});

//export router
export default router;