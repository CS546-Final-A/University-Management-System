
import md5 from "blueimp-md5"; 
const publickey = "c07303ac71a535a9033673318bb9d3b7";
const privatekey = "433c7f031706fbc596ec0f6ecc66b8dc8d05137c";

import validation from '../helpers.js'
import axios from "axios";

export const searchCharacterByName = async (name) => {
  //Function to search the api and return up to 15 characters matching the name param
   
  name = validation.checkString(name, "name"); 
  
const ts = new Date().getTime();
const stringToHash = ts + privatekey + publickey;
const hash = md5(stringToHash);
const baseUrl = "https://gateway.marvel.com:443/v1/public/characters";
const url = baseUrl + "?ts=" + ts + "&apikey=" + publickey + "&hash=" + hash+"&limit=15";
var searchURL = url +"&nameStartsWith=" + name ;
try{
  const { data } = await axios.get(searchURL);
  console.log(data);
  const characters = data.data.results;
 return characters
}catch(e){
  console.log(e);
}
  console.log(data)

  return data;


};

export const searchCharacterById = async (id) => {
  //Function to fetch a character from the api matching the id
  try{
  id = validation.checkString(id, "Id"); 
  id = parseInt(id);
  const ts = new Date().getTime();
  const stringToHash = ts + privatekey + publickey;
  const hash = md5(stringToHash);
  const baseUrl = "https://gateway.marvel.com:443/v1/public/characters";

  const url = baseUrl+ "/" + id + "?ts=" + ts + "&apikey=" + publickey + "&hash=" + hash+"&limit=15";

  let output;
    const { data } = await axios.get(url);
    output = data.data.results[0]
    console.log("Output is ",output)
    if(output){
      return data.data.results[0];
    }

  }
  catch(e){
    console.log(e);

    return "Character not found"
  }

};
