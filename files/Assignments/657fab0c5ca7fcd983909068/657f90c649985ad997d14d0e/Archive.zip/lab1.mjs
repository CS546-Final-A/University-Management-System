export const questionOne = (arr) => {
	const vowels = ["A", "E", "I", "O", "U"];
	const result = [];
	let count = 0;
	arr.forEach((word) => {
		vowels.forEach((letter) => {
			count += word.toUpperCase().split(letter).length - 1;
		});
	});
	result.push(count);
	result.push(count % 2 === 0);
	return result; //return result
};

export const questionTwo = (obj1, obj2) => {
	const keys1 = Object.keys(obj1);
	const keys2 = Object.keys(obj2);
	let result = [];

	keys1.forEach((key) => {
		if (!keys2.includes(key)) {
			result.push(key);
		}
	});
	keys2.forEach((key) => {
		if (!keys1.includes(key)) {
			result.push(key);
		}
	});

	let numkeys = result.filter((value) => {
		return !isNaN(value);
	});
	let strkeys = result.filter((value) => {
		return isNaN(value);
	});

	numkeys = numkeys.sort((a, b) => a - b);
	strkeys = strkeys.sort();

	result = numkeys.concat(strkeys);

	return result; //return result
};

function triangleArea(sides) {
	// Finds area using heron's formula https://www.wikihow.com/Calculate-the-Area-of-a-Triangle
	const side1 = sides[0];
	const side2 = sides[1];
	const side3 = sides[2];
	const s = (side1 + side2 + side3) / 2;
	let area = Math.sqrt(s * (s - side1) * (s - side2) * (s - side3));
	area = Math.round(area * 100) / 100;
	return area;
}

export const questionThree = (arr) => {
	const result = {};

	arr.forEach((triangle_sides, index) => {
		result[index] = [triangleArea(triangle_sides), triangle_sides[0] + triangle_sides[1] + triangle_sides[2]];
	});

	return result; //return result
};

function wordFunny(word) {
	const midpoint = word.length / 2;
	const first_half = word.slice(0, Math.ceil(midpoint));
	const second_half = word.slice(Math.ceil(midpoint));
	return second_half + first_half;
}

export const questionFour = (string) => {
	const result = [];
	const words = string.split(",");
	words.forEach((word) => {
		result.push(wordFunny(word));
	});

	return result; //return result
};

export const studentInfo = {
	firstName: "Michael",
	lastName: "Tarasov",
	studentId: "20019861",
};
